// ตัวเชื่อมเกมกับเซิร์ฟเวอร์ในเครื่องครู (แทนระบบของ claude.ai)
(function(){
  const rid=()=>Math.random().toString(36).slice(2,12);
  let uid;try{uid=localStorage.getItem("qb-uid");if(!uid){uid="u"+rid()+rid();localStorage.setItem("qb-uid",uid)}}catch(e){uid="u"+rid()}
  const ME=rid()+rid();
  const es=new EventSource("/api/events?id="+ME);
  let ready=new Promise(ok=>{es.onopen=()=>ok();setTimeout(ok,3000)});
  const docSubs=new Map();      // path -> Set(fn)
  const roomSubs=new Map();     // room -> {fns:Set, last}
  const joined=new Set();
  es.onmessage=e=>{let m;try{m=JSON.parse(e.data)}catch(_){return}
    if(m.t==="doc"){const s=docSubs.get(m.path);if(s)s.forEach(fn=>fn(snap(m.path,m.exists,m.data)))}
    if(m.t==="peers"){const r=roomSubs.get(m.room);const peers=m.peers.map(p=>({peer:p.peer,isMe:p.peer===ME,presence:Object.freeze(p.presence||{}),guest:false,kind:"viewer",by:null,updatedAt:Date.now()}));
      if(r){r.last=peers;r.fns.forEach(fn=>fn({peers,joined:[],updated:[],left:[]}))}}};
  // เชื่อมต่อใหม่แล้วเข้าห้องเดิม/ตั้งสถานะเดิมอีกครั้ง
  const lastPres=new Map();
  es.addEventListener("open",()=>{for(const n of joined){post("/api/room",{op:"presence",id:ME,room:n,patch:lastPres.get(n)||{}})}});
  function snap(p,exists,data){const d=data?JSON.parse(JSON.stringify(data)):undefined;return{id:p.split("/").pop(),exists:!!exists,data:()=>d,metadata:{fromCache:false,hasPendingWrites:false}}}
  async function post(url,b){const r=await fetch(url,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(b)});if(!r.ok)throw{code:"invalid_argument",message:"HTTP "+r.status};return r.json()}
  async function getDoc(p){const r=await fetch("/api/doc?path="+encodeURIComponent(p));if(!r.ok)throw{code:"unavailable",message:"HTTP "+r.status};const j=await r.json();return snap(p,j.exists,j.data)}
  const db={
    doc(p){return{id:p.split("/").pop(),path:p,
      get:()=>getDoc(p),
      set:d=>post("/api/doc",{op:"set",path:p,data:d}).then(()=>{}),
      update:d=>post("/api/doc",{op:"update",path:p,data:d}).then(()=>{}),
      delete:()=>post("/api/doc",{op:"delete",path:p}).then(()=>{}),
      onSnapshot(fn,err){if(!docSubs.has(p))docSubs.set(p,new Set());docSubs.get(p).add(fn);getDoc(p).then(fn).catch(e=>err&&err(e));return()=>{const s=docSubs.get(p);if(s)s.delete(fn)}}}},
    collection(c){const q=(f,v)=>({where:(f2,op,v2)=>q(f2,v2),get:async()=>{const r=await fetch("/api/query?coll="+encodeURIComponent(c)+(f?"&f="+encodeURIComponent(f)+"&v="+encodeURIComponent(v):""));const j=await r.json();const docs=j.docs.map(d=>snap(d.path,true,d.data));return{docs,size:docs.length,empty:!docs.length}}});return q()}
  };
  function makeRoom(name){
    if(!roomSubs.has(name))roomSubs.set(name,{fns:new Set(),last:[]});
    const R=roomSubs.get(name);let pres={};
    return{
      presence:async patch=>{await ready;Object.assign(pres,patch);for(const k in pres)if(pres[k]===null)delete pres[k];lastPres.set(name,pres);joined.add(name);return post("/api/room",{op:"presence",id:ME,room:name,patch}).then(()=>{})},
      onPeers(fn){R.fns.add(fn);if(R.last.length)setTimeout(()=>fn({peers:R.last,joined:[],updated:[],left:[]}),0);return()=>R.fns.delete(fn)},
      emit:async()=>{},on:()=>()=>{},
      leave:async()=>{joined.delete(name);lastPres.delete(name);roomSubs.delete(name);await post("/api/room",{op:"leave",id:ME,room:name})}
    };
  }
  const lobby=makeRoom("lobby");
  lobby.join=async name=>{await ready;joined.add(name);await post("/api/room",{op:"join",id:ME,room:name});return makeRoom(name)};
  ready.then(()=>{joined.add("lobby");post("/api/room",{op:"join",id:ME,room:"lobby"}).catch(()=>{})});
  const user={id:async()=>uid,me:async()=>({id:uid,name:""}),canEdit:async()=>true,can:async()=>true,isOwner:async()=>false,profiles:async()=>({})};
  window.claude={use:async n=>({db,user,room:lobby})[n]||null};
})();
