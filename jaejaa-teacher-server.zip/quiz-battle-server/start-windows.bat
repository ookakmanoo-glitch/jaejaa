@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul || (echo ยังไม่ได้ติดตั้ง Node.js  ดาวน์โหลดได้ที่ https://nodejs.org แล้วเปิดไฟล์นี้อีกครั้ง & pause & exit /b)
node server.js
pause
