// เซิร์ฟเวอร์เกม "QuizMon" — ใช้ Node.js อย่างเดียว ไม่ต้องติดตั้งอะไรเพิ่ม
// วิธีรัน: node server.js   (เปลี่ยนพอร์ตได้ด้วย PORT=8080 node server.js)
const http = require("http"), fs = require("fs"), path = require("path"), os = require("os"), crypto = require("crypto");

const PORT = +process.env.PORT || 3000;
const PUBLIC = path.join(__dirname, "public");
const DATA = path.join(__dirname, "data.json");

/* ---------- ฐานข้อมูล (เก็บลงไฟล์ data.json) ---------- */
let db = {};
try { db = JSON.parse(fs.readFileSync(DATA, "utf8")); } catch (e) { db = {}; }
let saveTimer = null;
function saveSoon() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    fs.writeFile(DATA + ".tmp", JSON.stringify(db), err => { if (!err) fs.rename(DATA + ".tmp", DATA, () => {}); });
  }, 300);
}
const validPath = p => typeof p === "string" && p.length < 600 && /^[A-Za-z0-9_\-.~:@+]+(\/[A-Za-z0-9_\-.~:@+]+)*$/.test(p);

/* ---------- ผู้เล่นที่เชื่อมต่ออยู่ ---------- */
const clients = new Map();      // id -> {res, rooms:Set}
const rooms = new Map();        // ชื่อห้อง -> Map(id -> presence)
const dirty = new Set();

function send(id, msg) { const c = clients.get(id); if (c) c.res.write(`data: ${JSON.stringify(msg)}\n\n`); }
function broadcast(msg) { const s = `data: ${JSON.stringify(msg)}\n\n`; for (const c of clients.values()) c.res.write(s); }
function joinRoom(id, name) {
  if (!rooms.has(name)) rooms.set(name, new Map());
  const r = rooms.get(name); if (!r.has(id)) r.set(id, {});
  const c = clients.get(id); if (c) c.rooms.add(name);
  dirty.add(name);
}
function leaveRoom(id, name) {
  const r = rooms.get(name); if (!r) return;
  r.delete(id); dirty.add(name);
  const c = clients.get(id); if (c) c.rooms.delete(name);
  if (!r.size) rooms.delete(name);
}
setInterval(() => {   // ส่งรายชื่อผู้เล่นในห้องให้ทุกคนในห้องนั้น ประมาณ 15 ครั้งต่อวินาที
  for (const name of dirty) {
    const r = rooms.get(name); const peers = r ? [...r].map(([peer, presence]) => ({ peer, presence })) : [];
    if (r) for (const id of r.keys()) send(id, { t: "peers", room: name, peers });
  }
  dirty.clear();
}, 66);
setInterval(() => { for (const c of clients.values()) c.res.write(": ping\n\n"); }, 20000);

/* ---------- HTTP ---------- */
const MIME = { ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".json": "application/json; charset=utf-8", ".webp": "image/webp", ".png": "image/png", ".css": "text/css", ".ico": "image/x-icon" };
function body(req) {
  return new Promise((ok, bad) => { let s = ""; req.on("data", d => { s += d; if (s.length > 2e6) { bad(new Error("too big")); req.destroy(); } }); req.on("end", () => { try { ok(s ? JSON.parse(s) : {}); } catch (e) { bad(e); } }); });
}
function json(res, code, obj) { res.writeHead(code, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" }); res.end(JSON.stringify(obj)); }

http.createServer(async (req, res) => {
  const u = new URL(req.url, "http://x");
  try {
    if (u.pathname === "/api/events") {
      const id = String(u.searchParams.get("id") || "").slice(0, 40);
      if (!/^[a-z0-9]+$/i.test(id)) return json(res, 400, { error: "bad id" });
      res.writeHead(200, { "Content-Type": "text/event-stream", "Cache-Control": "no-store", "Connection": "keep-alive", "X-Accel-Buffering": "no" });
      res.write(": hi\n\n");
      clients.set(id, { res, rooms: new Set() });
      req.on("close", () => { const c = clients.get(id); if (c && c.res === res) { for (const n of [...c.rooms]) leaveRoom(id, n); clients.delete(id); } });
      return;
    }
    if (u.pathname === "/api/doc" && req.method === "GET") {
      const p = u.searchParams.get("path"); if (!validPath(p)) return json(res, 400, { error: "bad path" });
      return json(res, 200, { exists: p in db, data: db[p] });
    }
    if (u.pathname === "/api/doc" && req.method === "POST") {
      const b = await body(req); const p = b.path; if (!validPath(p)) return json(res, 400, { error: "bad path" });
      if (b.op === "set") db[p] = b.data || {};
      else if (b.op === "update") db[p] = Object.assign({}, db[p] || {}, b.data || {});
      else if (b.op === "delete") delete db[p];
      else return json(res, 400, { error: "bad op" });
      saveSoon(); broadcast({ t: "doc", path: p, exists: p in db, data: db[p] });
      return json(res, 200, { ok: true });
    }
    if (u.pathname === "/api/query") {
      const coll = u.searchParams.get("coll"), f = u.searchParams.get("f"), v = u.searchParams.get("v");
      if (!validPath(coll)) return json(res, 400, { error: "bad path" });
      const depth = coll.split("/").length + 1;
      const docs = Object.keys(db).filter(k => k.startsWith(coll + "/") && k.split("/").length === depth && (!f || String(db[k][f]) === v)).map(k => ({ path: k, data: db[k] }));
      return json(res, 200, { docs });
    }
    if (u.pathname === "/api/room" && req.method === "POST") {
      const b = await body(req); const id = String(b.id || ""), name = String(b.room || "");
      if (!clients.has(id) || !/^[a-z0-9][a-z0-9_.-]{0,47}$/.test(name)) return json(res, 400, { error: "bad" });
      if (b.op === "join") joinRoom(id, name);
      else if (b.op === "leave") leaveRoom(id, name);
      else if (b.op === "presence") {
        joinRoom(id, name);
        const r = rooms.get(name), cur = Object.assign({}, r.get(id) || {});
        for (const [k, val] of Object.entries(b.patch || {})) { if (val === null) delete cur[k]; else cur[k] = val; }
        if (JSON.stringify(cur).length > 4096) return json(res, 400, { error: "too big" });
        r.set(id, cur); dirty.add(name);
      }
      return json(res, 200, { ok: true });
    }
    // ไฟล์เกม
    let fp = decodeURIComponent(u.pathname); if (fp === "/") fp = "/index.html";
    const full = path.join(PUBLIC, path.normalize(fp).replace(/^(\.\.[\/\\])+/, ""));
    if (!full.startsWith(PUBLIC)) { res.writeHead(403); return res.end(); }
    fs.readFile(full, (err, buf) => {
      if (err) { res.writeHead(404); return res.end("not found"); }
      res.writeHead(200, { "Content-Type": MIME[path.extname(full)] || "application/octet-stream", "Cache-Control": fp.endsWith(".html") ? "no-cache" : "max-age=3600" });
      res.end(buf);
    });
  } catch (e) { json(res, 500, { error: String(e.message || e) }); }
}).listen(PORT, "0.0.0.0", () => {
  console.log("\n  QuizMon — เซิร์ฟเวอร์ทำงานแล้ว\n");
  console.log(`  เครื่องนี้เปิด:            http://localhost:${PORT}`);
  for (const list of Object.values(os.networkInterfaces())) for (const a of list || [])
    if (a.family === "IPv4" && !a.internal) console.log(`  เครื่องอื่นใน Wi-Fi เดียวกัน: http://${a.address}:${PORT}`);
  console.log("\n  ปิดหน้าต่างนี้ = ปิดเซิร์ฟเวอร์ (ข้อมูลห้องเก็บไว้ในไฟล์ data.json)\n");
});
