#!/bin/bash
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then echo "ยังไม่ได้ติดตั้ง Node.js  ดาวน์โหลดได้ที่ https://nodejs.org แล้วเปิดไฟล์นี้อีกครั้ง"; read -r; exit 1; fi
node server.js
